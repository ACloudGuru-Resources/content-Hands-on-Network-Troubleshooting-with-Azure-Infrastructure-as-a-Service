﻿namespace EscapeRoomAdventure
{
    public class EscapeDetails
    {
        public string? YourName { get; set; }
        public string? UnlockCode { get; set; }

        public string StatusMessage { get; set; }
    }
}
